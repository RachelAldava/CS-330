#include "Chessboard.h"
#include "GLFW/glfw3.h" 
#include <cmath>
void Chessboard::LoadShapes() {
    Texture::textures blackSquareTex = Texture::woodCherry;
    Texture::textures whiteSquareTex = Texture::woodLight;
    Texture::textures accentBoardTex = Texture::woodDark;
    Texture::textures blackPieceTex = Texture::woodCherry;
    Texture::textures whitePieceTex = Texture::woodLight;


    Material::materials blackSquareMat = Material::paper;
    Material::materials whiteSquareMat = Material::paper;
    Material::materials accentBoardMst = Material::paper;
    Material::materials blackPieceMat = Material::paper;
    Material::materials whitePieceMat = Material::paper;

    float squareSpacing = 0.1f;
    float squareY = 0.0f;
    glm::vec3 squareScale = glm::vec3(squareSpacing/2, squareSpacing/2, squareSpacing/2);
    glm::vec3 squareRotation = glm::vec3(0.0f, 0.0f, 0.0f);

    // Init loop variables
    int squareID = 0;
    float currX = squareSpacing * 4 * -1;
    float currZ = squareSpacing * 4 * -1;
    bool isBlack = 1;
    glm::vec3 currPos;
    Shape* currPlane;
    Square currSquare;


    for (int File = 0; File < 8; File++) {//for every file
        for (int square = 0; square < 8; square++) {//create eight squares
            currPos = glm::vec3(currX, squareY, currZ);
            
            // get textures and materials
            if (isBlack) {
                currSquare.material = blackSquareMat;
                currSquare.texture = blackSquareTex;
            }
            else {
                currSquare.material = whiteSquareMat;
                currSquare.texture = whiteSquareTex;
            }
            
            // create Square object
            currSquare.location = glm::vec3(currX, squareY, currZ);
            currSquare.piece = nullptr;
            currSquare.plane = new Shape(
                Shape::plane,
                squareScale,// scale
                squareRotation,// rotation
                currSquare.location,// position
                currSquare.texture, 1.0f, 1.0f, // texture
                currSquare.material // material
            );

            // Add data to relevant sections
            AddToObject(currSquare.plane);
            squares[squareID] = currSquare;

            // prepare for next loop
            isBlack = !isBlack;
            currZ += squareSpacing;
            squareID++;
        }

        // prepare for next row
        isBlack = !isBlack;
        currZ = squareSpacing * 4 * -1;
        currX += squareSpacing;
    }


    float kingHeight = 0.1f;
    glm::vec3 currRotation = glm::vec3(0.0f, 0.0f, 0.0f);
    Piece currPiece;
    int count = 0;

    for (int coord = a1; coord <= h1; coord += 8) {
        std::cout << count << std::endl;
        currPiece.currLocation = squares[coord].location;
        currPiece.chessman = new Chessman(glm::vec3(kingHeight, kingHeight, kingHeight), currRotation, currPiece.currLocation);
        currPiece.hasTravel = false;
        AddToObject(currPiece.chessman);
        pieces[count] = currPiece;
        squares[coord].piece = &pieces[count];
        count++;
    }

}

Chessboard::Chessboard(glm::vec3 scaleXYZ, glm::vec3 rotationXYZ, glm::vec3 positionXYZ) {
    LoadShapes();
    InitiateObject(scaleXYZ, rotationXYZ, positionXYZ);
    lastframe = 0.0f;
    movementSpeed = 0.05f;// reasonable speed
    //movementSpeed = 0.01f; //testing speed

    pieces[whiteKing].travel = CreateTravel(&squares[e1], &squares[h8]);
}

Chessboard::Travel Chessboard::CreateTravel(Square* start, Square* destination) {
    Travel travel;
    float stepLength = 1.0f * movementSpeed;
    glm::vec3 startLocation = start->location;
    travel.endSquare = destination;

    float distanceX = travel.endSquare->location[0] - startLocation[0];
    float distanceZ = travel.endSquare->location[2] - startLocation[2];
    float totalDistance = sqrt((distanceX * distanceX) + (distanceZ * distanceZ));
    int stepCount = round(totalDistance / stepLength);
    travel.yMax = totalDistance / 2;
    travel.currY = 0;

    travel.stepX = distanceX / stepCount;
    travel.stepY = totalDistance / stepCount;
    travel.stepZ = distanceZ / stepCount;

    start->piece->hasTravel = true;
    start->piece = nullptr;

    return travel;
}

void Chessboard::Animate() {
    
    float currentFrame = glfwGetTime();
    float deltaTime = currentFrame - lastframe;
    lastframe = currentFrame;

    if (pieces[whiteKing].hasTravel) Animate(whiteKing, deltaTime);
}

void Chessboard::Animate(pieceIDs pieceID, float deltaTime) {
    Piece* piece = &pieces[pieceID];
    Travel* travel = &(piece->travel);
    
    float x = travel -> stepX * deltaTime;
    float y = travel -> stepY * deltaTime;
    float z = travel -> stepZ * deltaTime;

    travel -> currY += y;

    if (travel->currY > travel->yMax) y *= -1;
    if (travel->currY > travel->yMax * 2) {
        piece->hasTravel = false;
        piece->chessman->setPosition(travel->endSquare->location);
        travel->endSquare->piece = piece;
        return;
    }

    piece->currLocation[0] += x;
    piece->currLocation[1] += y;
    piece->currLocation[2] += z;

    piece->chessman->modifyRotation(glm::vec3(0.0f, 5.0f, 0.0f));
    piece->chessman->modifyPosition(glm::vec3(x, y, z));
}